<?php
include 'connection.php';

    $id = $_GET['id'];
    $sql = "DELETE FROM pharmaviews WHERE ID_Acao=$id";

    if ($conn->query($sql) === TRUE) {
        echo "removeu";
        header('Location: index.php');
    } else {
        echo "não removeu";
        header('Location: index.php');
    }
?>