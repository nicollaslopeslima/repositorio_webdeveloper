<?php   
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'];
    $data_prevista = $_POST['data_prevista'];
    $investimento_previsto = $_POST['investimento_previsto'];

    if (!empty($acao) && !empty($data_prevista) && !empty($investimento_previsto)) {
        $sql = "INSERT INTO pharmaviews (NM_Acao, DT_Prevista, DS_InvestimentoPrevisto) 
                VALUES ('$acao', '$data_prevista', '$investimento_previsto')";

        if (mysqli_query($conn, $sql)) {
            header('Location: index.php');
            exit;
        } else {
            header('Location: index.php');
        }
    } else {;
        header('Location: index.php');
    }
}

?>