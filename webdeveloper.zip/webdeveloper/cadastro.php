<?php   
include 'connection.php';
date_default_timezone_set('America/Sao_Paulo');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigo_acao = $_POST['codigo_acao'];
    $investimento = $_POST['investimento'];
    $data_prevista = $_POST['data_prevista'];
    $data_cadastro = new DateTime();
    $data_cadastro = $data_cadastro->format('Y-m-d H:i:s');

    if (!empty($codigo_acao) && !empty($investimento) && !empty($data_prevista)) {
        $sql = "INSERT INTO acao (codigo_acao, investimento, data_prevista, data_cadastro) 
                VALUES (?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "iiss", $codigo_acao, $investimento, $data_prevista, $data_cadastro);

            if (mysqli_stmt_execute($stmt)) {
                header('Location: index.php');
                exit;
            } else {
                header('Location: index.php');
            }
            mysqli_stmt_close($stmt);
        } else {          
            header('Location: index.php');
        }
    } else {
        header('Location: index.php');
    }
}

?>