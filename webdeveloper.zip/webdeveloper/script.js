$(document).ready(function() {
    $('#acaoTabela').DataTable({
            "paging": false,         
            "searching": false,       
            "info": false,             
            "lengthChange": false,
            columnDefs:[{
                orderable: false,
                targets: "no-sort"
            }]
        });
    });

    $('#investimentoPrevisto').mask('000.000.000.000.000,00', {reverse: true});

    $('#limparBtn').click(function() {
        $('#codigo_acao').val('');
        $('#dataPrevista').val('');
        $('#investimentoPrevisto').val('');
    });


    $('#formCadastro').submit(function(event) {
        var acao = $('#codigo_acao').val();
        var dataPrevista = $('#dataPrevista').val();
        var investimentoPrevisto = $('#investimentoPrevisto').val();

        if (acao === '' || dataPrevista === '' || investimentoPrevisto === '') {
            alert('Por favor, preencha todos os campos antes de enviar.');
            event.preventDefault(); 
        } else {
            var dataPrevistaDiferente = dayjs(dataPrevista.split('/').reverse().join('-'));
            var dataAtual = dayjs();
            var diferencaDias = dataPrevistaDiferente.diff(dataAtual, 'day');

            if (diferencaDias < 10) {
                alert('A data prevista deve ser no mínimo 10 dias após a data atual.');
                event.preventDefault();
            } else {
                alert('Dados salvos com sucesso!');
            }
        }
    });
