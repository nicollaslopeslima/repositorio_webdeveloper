$(document).ready(function() {
    // Aplicar a máscara de dinheiro
    $('#investimentoPrevisto').mask('000.000.000.000.000,00', {reverse: true});
    
    // Limpar os campos ao clicar no botão Limpar
    $('#limparBtn').click(function() {
        $('#acao').val('');
        $('#dataPrevista').val('');
        $('#investimentoPrevisto').val('');
    });

    // Validar campos antes de enviar
    $('#formCadastro').submit(function(event) {
        
        var acao = $('#acao').val();
        var dataPrevista = $('#dataPrevista').val();
        var investimentoPrevisto = $('#investimentoPrevisto').val();

        if (acao === '' || dataPrevista === '' || investimentoPrevisto === '') {
            alert('Por favor, preencha todos os campos antes de enviar.');
            event.preventDefault(); // Impede o envio do formulário
        } else {
            // Simulação de envio com redirecionamento após salvar
            alert('Dados salvos com sucesso!');
        }
    });
});