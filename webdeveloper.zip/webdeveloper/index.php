<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Verbas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</head>

<body>
    <div class="position-fixed top-0 start-0 w-100 bg-primary text-white d-flex align-items-center text-start" style="height: 70px; z-index: 1030; padding-left: 70px;">
    <img src="icone.png" class="img-fluid" alt="Logo PharmaViews" style= " width: 200px; height: auto;">
    </div>
    <div class="container-fluid mt-5 p-0">
        <div class="text-secondary bg-light d-flex align-items-center" style="height: 60px; z-index: 1030; padding-left: 50px; width: 100%;">
            <h2 class="m-0">Gestão de Verbas</h2>
        </div>
    </div>
    <div class="container-fluid mt-2" style="padding-left: 50px">
        <form action="cadastro.php" method="POST" class="row" id="formCadastro">
            <div class="col-md-3">
                <label class="form-label">Ação</label>
                <select class="form-select" name="acao" id="acao">
                    <option value="" selected readonly="true">Selecione o tipo da ação...</option>
                    <option value="Palestra">Palestra</option>
                    <option value="Workshop">Workshop</option>
                    <option value="Treinamento">Treinamento</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Data prevista</label>
                <input type="date" class="form-control" name="data_prevista" id="dataPrevista">
            </div>
            <div class="col-md-3">
                <label class="form-label">Investimento previsto</label>
                <input type="text" class="form-control" placeholder="R$ 0,00" name="investimento_previsto" id="investimentoPrevisto">
            </div>

            <div class="col-md-2 d-flex align-items-end gap-2">
                <button type="button" class="btn btn-warning text-white" id="limparBtn">Limpar</button>
                <button type="submit" class="btn btn-success">Adicionar</button>
            </div>
        </form>
    </div>

    <div class="container col-md-12" >
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Ação</th>
                    <th scope="col">Data prevista</th>
                    <th scope="col">Investimento Previsto</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT ID_Acao, NM_Acao, DT_Prevista, DS_InvestimentoPrevisto FROM pharmaviews";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td>
                                <?php echo $row["NM_Acao"]; ?>
                            </td>
                            <td>
                                <?php echo $row["DT_Prevista"]; ?>
                            </td>
                            <td>
                                <?php echo $row["DS_InvestimentoPrevisto"]; ?>
                            </td>
                            <td>
                                <a href="edit.php?id=<?php echo $row["ID_Acao"] ?>">
                                    <button class="btn">
                                    <i class="bi bi-pencil"></i>
                                    </button>
                                </a>
                            </td>
                            <td>
                                <a href="remove.php?id=<?php echo $row["ID_Acao"] ?>">
                                    <button class="btn">
                                    <i class="bi bi-trash3-fill"></i>
                                    </button>
                                </a>
                            </td>
                        </tr>
                <?php   }
                } else {
                    echo "Nenhum resultado encontrado";
                }
                ?>
            </tbody>
        </table>
    </div>

    </div>

    <div class="position-fixed bottom-0 start-0 w-100 bg-primary text-white d-flex align-items-center   text-start" style="height: 50px; z-index: 1030; padding-left: 30px;">
        ©2024 PHARMAVIEWS Todos os direitos reservados.
    </div>

    <script src="script.js"></script>
</body>

</html>