<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Verbas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="https://cdn.jsdelivr.net/npm/dayjs@1.10.7/dayjs.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
</head>

<body>
    <div class="position-fixed top-0 start-0 w-100 bg-primary text-white d-flex align-items-center text-start" style="height: 70px; z-index: 1030; padding-left: 70px;">
    <img src="icone.png" class="img-fluid" alt="Logo PharmaViews" style= " width: 200px; height: auto;">
    </div>
    <div class="container-fluid mt-5 p-0">
        <div class="text-secondary bg-light d-flex align-items-center" style="height: 60px; z-index: 1030; padding-left: 50px; width: 100%;">
            <h2 class="m-0">Gestão de Verbas</h2>
        </div>
    </div>
    <div class="container" style="padding-left: 50px">
        <form action="cadastro.php" method="POST" class="row" id="formCadastro">
            <div class="col-md-4">
                <label class="form-label">Ação</label>
                <select class="form-select" name="codigo_acao" id="codigo_acao">
                    <option value="" selected readonly="true">Selecione o tipo da ação...</option>
                    <option value="1">Palestra</option>
                    <option value="2">Workshop</option>
                    <option value="3">Treinamento</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Data prevista</label>
                <input type="date" class="form-control" name="data_prevista" id="dataPrevista">
            </div>
            
            <div class="col-md-2">
                <label class="form-label">Investimento previsto</label>
                <input type="text" class="form-control" placeholder="R$ 0,00" name="investimento" id="investimentoPrevisto">
            </div>

            <div class="col-md-2 d-flex align-items-end gap-2">
                <div class="w-50">
                    <button type="button" class="btn btn-warning text-white d-flex align-items-center justify-content-center" id="limparBtn">
                        <i class="bi bi-trash" style="margin-right: 8px;"></i> Limpar
                    </button>
                </div>
                <div class="w-50">
                    <button type="submit" class="btn btn-success d-flex align-items-center justify-content-center">
                        <i class="bi bi-plus" style="margin-right: 8px;"></i> Adicionar
                    </button>
                </div>
            </div>


        </form>

        <table class="table table-bordered border-top" id="acaoTabela">
            <thead>
                <tr>
                    <th scope="col">Ação</th>
                    <th scope="col">Data prevista</th>
                    <th scope="col">Investimento Previsto</th>
                    <th scope="col" class="text-center no-sort">Editar</th>
                    <th scope="col" class="text-center no-sort">Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT acao.id, tipo_acao.nome_acao, acao.investimento, acao.data_prevista
                        FROM acao
                        INNER JOIN tipo_acao
                        ON acao.codigo_acao = tipo_acao.codigo_acao;";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td>
                                <?php echo $row["nome_acao"]; ?>
                            </td>
                            <td>
                                <?php echo $row["data_prevista"]; ?>
                            </td>
                             <td>                       
                                <?php echo "R$" . $row["investimento"]; ?>
                            </td>
                            <td>
                                <a href="edit.php?id=<?php echo $row["id"] ?>">
                                    <button class="btn d-flex align-items-center justify-content-center" style="width: 100%; height: 100%;">
                                    <i class="bi bi-pencil"></i>
                                    </button>
                                </a>
                            </td>
                            <td>
                                <a href="remove.php?id=<?php echo $row["id"] ?>">
                                    <button class="btn d-flex align-items-center justify-content-center" style="width: 100%; height: 100%;">
                                    <i class="bi bi-trash3-fill"></i>
                                    </button>
                                </a>
                            </td>
                        </tr>
                <?php   }
                } else {
                    echo "Nenhum resultado encontrado";
                }
                ?>
                
            </tbody>
        </table>
    </div>

    </div>
    <div class="bg-light" style="width: 100%; height: 100vh;""></div>
    <div class="position-fixed bottom-0 start-0 w-100 bg-primary text-white d-flex align-items-center   text-start" style="height: 50px; z-index: 1030; padding-left: 30px;">
        ©2024 PHARMAVIEWS Todos os direitos reservados.
    </div>

    <script src="script.js"></script>
</body>

</html>