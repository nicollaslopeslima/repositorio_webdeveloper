<?php
include 'connection.php';

$id_acao = $_GET['id'];  

$sql = "SELECT codigo_acao, investimento, data_prevista FROM acao WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_acao);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $codigo_acao = $row["codigo_acao"];
    $investimento = $row["investimento"];
    $data_prevista = $row["data_prevista"];
} else {
    echo "Ação não encontrada!";
    exit;
}
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_acao = $_POST['codigo_acao'];
    $data_prevista = $_POST['data_prevista'];
    $investimento = $_POST['investimento'];

    $investimento = str_replace(['R$', '.', ','], ['', '', '.'], $investimento);

     $sql = "UPDATE acao SET codigo_acao = ?, investimento = ?, data_prevista = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssi", $codigo_acao, $investimento, $data_prevista, $id_acao);


    if (mysqli_stmt_execute($stmt)) {
        echo "Alterado com sucesso!";
        header('Location: index.php');
        exit;
    } else {
        echo "Erro ao atualizar: " . mysqli_error($conn);
    }
 }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Verbas - Edição</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</head>

<body>
    <div class="position-fixed top-0 start-0 w-100 bg-primary text-white d-flex align-items-center text-start" style="height: 70px; z-index: 1030; padding-left: 70px;">
    <img src="icone.png" class="img-fluid" alt="Logo PharmaViews" style= " width: 200px; height: auto;">
    </div>

    <div class="container-fluid mt-5 p-0">
        <div class="text-secondary bg-light d-flex align-items-center" style="height: 60px; z-index: 1030; padding-left: 40px; width: 100%;">
            <h2 class="m-0">Edição de Ação</h2>
        </div>
    </div>

    <div class="container-fluid mt-2">
        <form action="" method="POST" class="row" id="formCadastro">
            <input type="hidden" name="id_acao" value="<?php echo $id_acao; ?>"> 

            <div class="col-md-3">
                <label class="form-label">Ação</label>
                <select class="form-select" name="codigo_acao" id="codigo_acao">
                    <option value="" selected readonly="true">Selecione o tipo da ação...</option>
                    <option value="1" <?php echo ($codigo_acao == '1') ? 'selected' : ''; ?>>Palestra</option>
                    <option value="2" <?php echo ($codigo_acao == '2') ? 'selected' : ''; ?>>Workshop</option>
                    <option value="3" <?php echo ($codigo_acao == '3') ? 'selected' : ''; ?>>Treinamento</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label class="form-label">Data prevista</label>
                <input type="date" class="form-control" name="data_prevista" id="dataPrevista" value="<?php echo $data_prevista; ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label">Investimento previsto</label>
                <input type="text" class="form-control" placeholder="R$ 0,00" name="investimento" id="investimentoPrevisto" value="<?php echo $investimento; ?>">
            </div>

            <div class="col-md-2 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-success">Salvar</button>
            </div>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>