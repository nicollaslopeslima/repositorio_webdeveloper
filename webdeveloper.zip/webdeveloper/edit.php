<?php
include 'connection.php';



// Suponha que você tenha o ID da ação que você deseja editar
$id_acao = $_GET['id'];  // Pegue o ID da URL, por exemplo: editar.php?id=1

// Realize a consulta para pegar os dados da ação a ser editada
$sql = "SELECT NM_Acao, DT_Prevista, DS_InvestimentoPrevisto FROM pharmaviews WHERE ID_Acao = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_acao); // "i" para inteiro
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $acao = $row["NM_Acao"];
    $data_prevista = $row["DT_Prevista"];
    $investimento_previsto = $row["DS_InvestimentoPrevisto"];
} else {
    // Caso não encontre a ação, você pode redirecionar ou mostrar um erro
    echo "Ação não encontrada!";
    exit;
}
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Receba os dados do formulário
    $acao = $_POST['acao'];
    $data_prevista = $_POST['data_prevista'];
    $investimento_previsto = $_POST['investimento_previsto'];

     // Se necessário, trate o valor do investimento para garantir que ele seja salvo corretamente
    // Por exemplo, se for em formato monetário, remova a máscara
    $investimento_previsto = str_replace(['R$', '.', ','], ['', '', '.'], $investimento_previsto);

     $sql = "UPDATE pharmaviews SET NM_Acao = ?, DT_Prevista = ?, DS_InvestimentoPrevisto = ? WHERE ID_Acao = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssi", $acao, $data_prevista, $investimento_previsto, $id_acao);


    if (mysqli_stmt_execute($stmt)) {
        echo "Alterado com sucesso!";
        header('Location: index.php');
        exit;
    } else {
        echo "Erro ao atualizar: " . mysqli_error($conn);
    }
 }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Verbas - Edição</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</head>

<body>
    <div class="position-fixed top-0 start-0 w-100 bg-primary text-white d-flex align-items-center text-start" style="height: 60px; z-index: 1030; padding-left: 70px;">
        <h1>PharmaViews</h1>
    </div>

    <div class="container-fluid mt-5 p-0">
        <div class="text-secondary bg-light d-flex align-items-center" style="height: 60px; z-index: 1030; padding-left: 40px; width: 100%;">
            <h2 class="m-0">Edição de Ação</h2>
        </div>
    </div>

    <div class="container-fluid mt-2">
        <form action="" method="POST" class="row" id="formCadastro">
            <input type="hidden" name="id_acao" value="<?php echo $id_acao; ?>"> <!-- Esconde o ID da ação -->

            <div class="col-md-3">
                <label class="form-label">Ação</label>
                <select class="form-select" name="acao" id="acao">
                    <option value="" selected readonly="true">Selecione o tipo da ação...</option>
                    <option value="Palestra" <?php echo ($acao == 'Palestra') ? 'selected' : ''; ?>>Palestra</option>
                    <option value="Workshop" <?php echo ($acao == 'Workshop') ? 'selected' : ''; ?>>Workshop</option>
                    <option value="Treinamento" <?php echo ($acao == 'Treinamento') ? 'selected' : ''; ?>>Treinamento</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label class="form-label">Data prevista</label>
                <input type="date" class="form-control" name="data_prevista" id="dataPrevista" value="<?php echo $data_prevista; ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label">Investimento previsto</label>
                <input type="text" class="form-control" placeholder="R$ 0,00" name="investimento_previsto" id="investimentoPrevisto" value="<?php echo $investimento_previsto; ?>">
            </div>

            <div class="col-md-2 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-success">Salvar</button>
            </div>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>